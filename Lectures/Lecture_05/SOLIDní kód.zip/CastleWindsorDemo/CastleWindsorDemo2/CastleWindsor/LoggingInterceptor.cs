using Castle.DynamicProxy;
using System;

namespace CastleWindsorDemo2.CastleWindsor
{
    public class LoggingInterceptor : IInterceptor
    {
        public void Intercept(IInvocation invocation)
        {
            this.PrintLogMessage($"Method: {invocation.Method.Name} start");
            try
            {
                invocation.Proceed();
                this.PrintLogMessage($"Method: {invocation.Method.Name} was succeed");
            }
            catch (Exception e)
            {
                PrintLogError($"Exception {e} was raised in Method: {invocation.Method.Name}");
                throw;
            }
            this.PrintLogMessage($"Method: {invocation.Method.Name} exit");
        }

        private void PrintColorText(ConsoleColor color, string message, params object[] args)
        {
            var originalColor = Console.ForegroundColor;
            Console.ForegroundColor = color;
            Console.WriteLine(message, args);
            Console.ForegroundColor = originalColor;
        }

        private void PrintLogError(string message, params object[] args)
        {
            this.PrintColorText(ConsoleColor.Red, message, args);
        }

        private void PrintLogMessage(string message, params object[] args)
        {
            this.PrintColorText(ConsoleColor.Yellow, message, args);
        }
    }
}