namespace CastleWindsorDemo2.IMailers
{
    internal interface IMailerService
    {
        void SendEmail(string to, string subject, string body);
    }
}