using Castle.Core;
using CastleWindsorDemo2.CastleWindsor;
using System;

namespace CastleWindsorDemo2.IMailers
{
    internal class MailerService : IMailerService
    {
        public void SendEmail(string to, string subject, string body)
        {
            Console.WriteLine($"Send email to: {to}");
            Console.WriteLine($"\t{subject} - {body}");
        }
    }
}