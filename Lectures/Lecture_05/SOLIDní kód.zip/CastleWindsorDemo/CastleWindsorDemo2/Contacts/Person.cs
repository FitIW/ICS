namespace CastleWindsorDemo2.Contacts
{
    internal class Person
    {
        public string Email { get; }

        public string Name { get; }

        public bool NewsletterWasOpen { get; set; }

        public bool NewsletterWasSend { get; set; }

        public Person(string name, string email)
        {
            Name = name;
            Email = email;
            NewsletterWasSend = false;
            NewsletterWasOpen = false;
        }
    }
}