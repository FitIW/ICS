using System.Collections.Generic;

namespace CastleWindsorDemo2.Contacts
{
    internal class ContactList
    {
        public IList<Person> Contacts { get; }

        public ContactList()
        {
            this.Contacts = new List<Person>();
        }

        public void LoadContacts(string filename)
        {
            Contacts.Add(new Person("Martin Dybal", "martin@dybal.it"));
            Contacts.Add(new Person("Roman Ja�ek", "roman.jasek@hotmail.com"));
        }
    }
}