namespace CastleWindsorDemo2.INewsletterServices
{
    internal interface INewsletterService
    {
        void SendNewsletters();
    }
}