using CastleWindsorDemo2.CastleWindsor;
using CastleWindsorDemo2.Contacts;
using CastleWindsorDemo2.IMailers;

namespace CastleWindsorDemo2.INewsletterServices
{
    internal class NewsletterService : INewsletterService
    {
        private readonly ContactList contactList;

        private readonly IMailerService mailerService;

        public NewsletterService(ContactList contactList, IMailerService mailerService)
        {
            this.contactList = contactList;
            this.mailerService = mailerService;
        }

        public void SendNewsletters()
        {
            string subject = "Máme pro vás jedinečnou nabídku!";
            string body = "Začněte používat návrhové vzory právě teď!";

            foreach (var person in contactList.Contacts)
            {
                mailerService.SendEmail(person.Email, subject, body);
                person.NewsletterWasSend = true;
            }
        }
    }
}