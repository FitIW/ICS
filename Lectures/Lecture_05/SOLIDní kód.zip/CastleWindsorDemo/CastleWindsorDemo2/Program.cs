﻿using Castle.MicroKernel.Registration;
using Castle.Windsor;
using CastleWindsorDemo2.CastleWindsor;
using CastleWindsorDemo2.Contacts;
using CastleWindsorDemo2.IMailers;
using CastleWindsorDemo2.INewsletterServices;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace CastleWindsorDemo2
{
    internal class Program
    {
        private static WindsorContainer CreateContainer()
        {
            var container = new WindsorContainer();
            container.Register(Component.For<ContactList>().ImplementedBy<ContactList>().LifestyleSingleton());
            container.Register(Component.For<INewsletterService>().ImplementedBy<NewsletterService>().LifestyleTransient());
            container.Register(Component.For<IMailerService>().ImplementedBy<MailerService>().LifestyleTransient().Interceptors<LoggingInterceptor>());

            container.Register(Component.For<LoggingInterceptor>().LifestyleTransient());
            container.Register(Component.For<App>().LifestyleTransient());

            return container;
        }

        private static void Main(string[] args)
        {
            //var contactList = new ContactList();
            //var app = new App(contactList, new NewsletterService(contactList, new MailerService()));
            //app.Run();

            var container = CreateContainer();
            var app = container.Resolve<App>();
            app.Run();
        }
    }
}