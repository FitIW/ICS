using CastleWindsorDemo2.CastleWindsor;
using CastleWindsorDemo2.Contacts;
using CastleWindsorDemo2.INewsletterServices;
using System;
using System.Linq;

namespace CastleWindsorDemo2
{
    internal class App
    {
        private readonly ContactList contactList;
        private readonly INewsletterService newsletterService;

        public App(ContactList contactList, INewsletterService newsletterService)
        {
            this.contactList = contactList;
            this.newsletterService = newsletterService;
        }

        public void Run()
        {
            contactList.LoadContacts("filename");
            newsletterService.SendNewsletters();
        }
    }
}