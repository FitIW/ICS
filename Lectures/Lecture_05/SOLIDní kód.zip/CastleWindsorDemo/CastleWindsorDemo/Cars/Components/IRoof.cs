﻿namespace CastleWindsorDemo.Cars.Components
{
    public interface IRoof
    {
    }
}