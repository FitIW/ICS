namespace CastleWindsorDemo.Cars.Components
{
    public interface IEngine
    {
        int MaxSpeed { get; }
    }
}