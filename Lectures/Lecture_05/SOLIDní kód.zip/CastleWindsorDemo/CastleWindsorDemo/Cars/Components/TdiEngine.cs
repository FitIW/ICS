﻿namespace CastleWindsorDemo.Cars.Components
{
    internal class TdiEngine : IEngine
    {
        public int MaxSpeed { get; private set; }

        public TdiEngine()
        {
            this.MaxSpeed = 210;
        }

        public override string ToString()
        {
            return "tdi";
        }
    }
}