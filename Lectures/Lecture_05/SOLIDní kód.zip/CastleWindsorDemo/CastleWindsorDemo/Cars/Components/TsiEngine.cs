namespace CastleWindsorDemo.Cars.Components
{
    internal class TsiEngine : IEngine
    {
        public int MaxSpeed { get; private set; }

        public TsiEngine()
        {
            this.MaxSpeed = 230;
        }

        public override string ToString()
        {
            return "tsi";
        }
    }
}