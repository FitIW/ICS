namespace CastleWindsorDemo.Cars.Components
{
    public class FoldingRoof : IRoof
    {
        public override string ToString()
        {
            return "folding roof";
        }
    }
}