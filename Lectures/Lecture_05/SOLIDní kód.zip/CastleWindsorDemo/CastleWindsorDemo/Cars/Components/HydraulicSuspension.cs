﻿using Castle.Core.Internal;

namespace CastleWindsorDemo.Cars.Components
{
    internal class HydraulicSuspension : ISuspension
    {
        public double Adhesion { get; private set; }

        public HydraulicSuspension()
        {
            Adhesion = 0.95;
        }

        public override string ToString()
        {
            return "hydraulic suspension";
        }
    }
}