namespace CastleWindsorDemo.Cars.Components
{
    public interface ISuspension
    {
        double Adhesion { get; }
    }
}