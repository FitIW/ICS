using CastleWindsorDemo.Cars.Components;

namespace CastleWindsorDemo.Cars
{
    public class Car
    {
        public IEngine Engine { get; private set; }

        public IRoof Roof { get; set; }

        public ISuspension Suspension { get; private set; }

        public Car(IEngine engine, ISuspension suspension)
        {
            this.Engine = engine;
            this.Suspension = suspension;
        }

        public override string ToString()
        {
            return $"Car with {Roof}, {Suspension} and {Engine} engine";
        }
    }
}