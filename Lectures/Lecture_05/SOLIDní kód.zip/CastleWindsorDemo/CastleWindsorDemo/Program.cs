﻿using System;
using Castle.Core.Logging;
using Castle.Facilities.TypedFactory;
using Castle.MicroKernel.Registration;
using Castle.Windsor;
using CastleWindsorDemo.Cars;
using CastleWindsorDemo.Cars.Components;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace CastleWindsorDemo
{
    internal class Program
    {
        private static WindsorContainer container;

        private static void ContrainerBootstrap()
        {
            container = new WindsorContainer();
            container.Register(Component.For<Car>().LifestyleTransient());
            container.Register(Component.For<ISuspension>().ImplementedBy<HydraulicSuspension>().LifestyleTransient());
            container.Register(Component.For<IEngine>().ImplementedBy<TdiEngine>().LifestyleTransient());
            container.Register(Component.For<IRoof>().ImplementedBy<FoldingRoof>().LifestyleTransient());
        }

        private static void Main(string[] args)
        {
            ContrainerBootstrap();

            var car = new Car(new TdiEngine(), new HydraulicSuspension());

            var car2 = container.Resolve<Car>();

            Console.WriteLine(car);
            Console.WriteLine(car2);
        }
    }
}