﻿using System.Collections;
using System.Collections.Generic;

namespace HtmlHelper
{
    public abstract class HtmlCollectionBase<T> : IReadOnlyList<T>
    {
        private readonly List<T> items = new List<T>();

        public T this[int index]
        {
            get
            {
                return this.items[index];
            }
        }

        public int Count
        {
            get
            {
                return this.items.Count;
            }
        }

        public void Add(T item)
        {
            this.items.Add(item);
        }

        public IEnumerator<T> GetEnumerator()
        {
            return this.items.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        public void Remove(T item)
        {
            this.items.Remove(item);
        }

        public abstract override string ToString();
    }
}