﻿using System.Linq;

namespace HtmlHelper.Attributes
{
    public class HtmlAttributes : HtmlCollectionBase<HtmlAttribute>
    {
        public override string ToString()
        {
            return string.Join(" ", this.OrderBy(a => a.Name));
        }
    }
}