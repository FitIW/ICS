using HtmlHelper.Elements;
using System.Linq;

namespace HtmlHelper.Attributes
{
    public class HtmlElements : HtmlCollectionBase<HtmlElement>
    {
        public override string ToString()
        {
            if (this.Any())
            {
                return string.Join("", this);
            }
            return string.Empty;
        }
    }
}