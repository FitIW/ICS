using System.Linq;

namespace HtmlHelper.Attributes
{
    public class HtmlClasses : HtmlCollectionBase<string>
    {
        public override string ToString()
        {
            if (this.Any())
            {
                return string.Format("class='{0}'", string.Join(" ", this));
            }
            return string.Empty;
        }
    }
}