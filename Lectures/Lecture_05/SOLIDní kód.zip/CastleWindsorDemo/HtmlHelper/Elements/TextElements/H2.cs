namespace HtmlHelper.Elements.TextElements
{
    public class H2 : HtmlTextElement
    {
        public H2(string text)
            : base("h2", text)
        {
        }
    }
}