namespace HtmlHelper.Elements.TextElements
{
    public class H5 : HtmlTextElement
    {
        public H5(string text)
            : base("h5", text)
        {
        }
    }
}