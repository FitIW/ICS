namespace HtmlHelper.Elements.TextElements
{
    public class H4 : HtmlTextElement
    {
        public H4(string text)
            : base("h4", text)
        {
        }
    }
}