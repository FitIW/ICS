namespace HtmlHelper.Elements.TextElements
{
    public class H6 : HtmlTextElement
    {
        public H6(string text)
            : base("h6", text)
        {
        }
    }
}