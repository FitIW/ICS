namespace HtmlHelper.Elements.TextElements
{
    public class Span : HtmlTextElement
    {
        public Span(string text)
            : base("span", text)
        {
        }
    }
}