﻿namespace HtmlHelper.Elements.TextElements
{
    public abstract class HtmlTextElement : HtmlElement
    {
        protected HtmlTextElement(string tagName, string text)
            : base(tagName)
        {
            this.InnerText = text;
        }
    }
}