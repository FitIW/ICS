namespace HtmlHelper.Elements.TextElements
{
    public class H3 : HtmlTextElement
    {
        public H3(string text)
            : base("h3", text)
        {
        }
    }
}