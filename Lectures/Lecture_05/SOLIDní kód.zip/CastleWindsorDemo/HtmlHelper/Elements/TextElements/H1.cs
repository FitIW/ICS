namespace HtmlHelper.Elements.TextElements
{
    public class H1 : HtmlTextElement
    {
        public H1(string text)
            : base("h1", text)
        {
        }
    }
}