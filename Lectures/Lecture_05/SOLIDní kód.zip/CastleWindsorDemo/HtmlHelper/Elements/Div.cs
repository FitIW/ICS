namespace HtmlHelper.Elements
{
    public class Div : HtmlElement
    {
        public Div()
            : base("div")
        {
        }
    }
}