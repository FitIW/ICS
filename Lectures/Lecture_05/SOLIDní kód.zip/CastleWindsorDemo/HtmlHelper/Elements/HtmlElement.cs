using HtmlHelper.Attributes;

namespace HtmlHelper.Elements
{
    public abstract class HtmlElement
    {
        private readonly HtmlAttributes attributes = new HtmlAttributes();
        private readonly HtmlClasses classes = new HtmlClasses();
        private readonly HtmlElements innerElements = new HtmlElements();

        public string Id { get; set; }

        public string InnerText { get; set; }

        public string TagName { get; private set; }

        protected HtmlElement(string tagName)
        {
            this.TagName = tagName;
        }

        public HtmlElement AddAttribute(HtmlAttribute attribute)
        {
            this.attributes.Add(attribute);
            return this;
        }

        public HtmlElement AddClass(string className)
        {
            this.classes.Add(className);
            return this;
        }

        public HtmlElement AddElement(HtmlElement element)
        {
            this.innerElements.Add(element);
            return this;
        }

        public HtmlElement RemoveAttribute(HtmlAttribute attribute)
        {
            this.attributes.Remove(attribute);
            return this;
        }

        public HtmlElement RemoveClass(string className)
        {
            this.classes.Remove(className);
            return this;
        }

        public HtmlElement RemoveElement(HtmlElement element)
        {
            this.innerElements.Remove(element);
            return this;
        }

        public override string ToString()
        {
            return string.Format("<{0} {1}>{2}{3}</{0}>", this.TagName, string.Join(" ", this.IdToString(), this.classes, this.attributes), this.InnerText, this.innerElements);
        }

        private string IdToString()
        {
            if (string.IsNullOrWhiteSpace(this.Id))
            {
                return string.Empty;
            }
            return string.Format("id='{0}'", this.Id);
        }
    }
}