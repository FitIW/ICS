﻿using HtmlHelper.Attributes;
using HtmlHelper.Elements;
using HtmlHelper.Elements.TextElements;
using System;

namespace HtmlHelper
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Div main = new Div();
            main.AddAttribute(new HtmlAttribute("id", "Main")).AddClass("contrainer")
                .AddElement(new H1("Title").AddClass("title"))
                .AddElement(
                    new Div().AddClass("Menu")
                        .AddElement(new Div().AddClass("menu-item").AddElement(new Span("Menu item 1")))
                        .AddElement(new Div().AddClass("menu-item").AddElement(new Span("Menu item 2")))
                        .AddElement(new Div().AddClass("menu-item").AddElement(new Span("Menu item 2")))
                    )
            ;

            Console.WriteLine(main);
        }
    }
}