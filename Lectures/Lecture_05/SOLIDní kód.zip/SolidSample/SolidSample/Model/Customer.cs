﻿namespace SolidSample.Model
{
    public class Customer
    {
        public string Name { get; set; }
    }
}