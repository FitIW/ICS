﻿using Microsoft.EntityFrameworkCore;

namespace SolidSample.Model
{
    public class AppDbContext : DbContext
    {
        public DbSet<Customer> Customers { get; set; }
    }
}