﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SolidSample.Model;

namespace SolidSample.Controllers
{
    [Route("api/[controller]")]
    public class CustomersController : Controller
    {
        [HttpGet]
        public Customer[] GetCustomers()
        {
            return new[] { new Customer { Name = "Riganti" }, new Customer { Name = "DotNETcollege" } };
        }

        [HttpPost]
        public void SaveCustomer(Customer customer)
        {
            using (var dbContext = new AppDbContext())
            {
                try
                {
                    dbContext.Customers.Add(customer);
                    dbContext.SaveChanges();
                }
                catch (Exception ex)
                {
                    System.IO.File.AppendAllText($"logs\\{DateTime.Now:yyyy-MM-dd}.log", DateTime.Now + ": " + ex + "\r\n");
                }
            }
        }
    }
}
